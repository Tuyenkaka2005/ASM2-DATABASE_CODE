﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Product_Shoes
{
    public partial class Employee : Form
    {
        private string connectionString;
        private SqlConnection connection;
        public Employee()
        {
            InitializeComponent();
            connectionString = @"Data Source=TUYENPRO\SQLEXPRESS01;Initial Catalog=""ShoeSalesManager"";Integrated Security=True;TrustServerCertificate=True";
            connection = new SqlConnection(connectionString);
            dataGridViewEmployee.SelectionChanged += dataGridViewEmployee_SelectionChanged;

            LoadEmployeeIntoGridView();
        }
        private void LoadEmployeeIntoGridView()
        {
            try
            {
                string query = "SELECT * FROM [dbo].[Employee]";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridViewEmployee.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void dataGridViewEmployee_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewEmployee.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridViewEmployee.SelectedRows[0];
                UpdateEmployeePanel(selectedRow);
            }
        }
        private void UpdateEmployeePanel(DataGridViewRow row)
        {
            try
            {
                txtEmployeeID.Text = row.Cells["EmployeeID"].Value.ToString();
                txtCode.Text = row.Cells["EmployeeCode"].Value.ToString();
                txtName.Text = row.Cells["EmployeeName"].Value.ToString();
                txtPosition.Text = row.Cells["Position"].Value.ToString();
                txtLevel.Text = row.Cells["AuthorityLevel"].Value.ToString();
                txtUserName.Text = row.Cells["Username"].Value.ToString();
                txtPassword.Text = row.Cells["Password"].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating info panel: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtSearch.Text, out int employeeId))
            {
                DataGridViewRow employeeRow = null;
                foreach (DataGridViewRow row in dataGridViewEmployee.Rows)
                {
                    if (row.Cells["EmployeeID"].Value != null && (int)row.Cells["EmployeeID"].Value == employeeId)
                    {
                        employeeRow = row;
                        break;
                    }
                }

                if (employeeRow != null)
                {
                    StringBuilder result = new StringBuilder();
                    result.AppendLine($"Employee ID: {employeeId}");
                    result.AppendLine($"Employee Code: {employeeRow.Cells["EmployeeCode"].Value}");
                    result.AppendLine($"Employee Name: {employeeRow.Cells["EmployeeName"].Value}");
                    result.AppendLine($"Position: {employeeRow.Cells["Position"].Value}");
                    result.AppendLine($"Authority Level: {employeeRow.Cells["AuthorityLevel"].Value}");
                    result.AppendLine($"User Name: {employeeRow.Cells["Username"].Value}");
                    result.AppendLine($"Password: {employeeRow.Cells["Password"].Value}");
                    txtResult.Text = result.ToString();
                }
                else
                {
                    txtResult.Text = "Employee not found.";
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid Employee ID.");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "INSERT INTO [dbo].[Employee] (EmployeeCode,EmployeeName, Position, AuthorityLevel,Username,Password) VALUES (@code,@name, @pos, @AL,@us, @ps)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@code", txtCode.Text);
                    cmd.Parameters.AddWithValue("@name", txtName.Text);
                    cmd.Parameters.AddWithValue("@pos", txtPosition.Text);
                    cmd.Parameters.AddWithValue("@AL", txtLevel.Text);
                    cmd.Parameters.AddWithValue("@us", txtUserName.Text); ;
                    cmd.Parameters.AddWithValue("@ps", txtPassword.Text);

                    connection.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Employee added successfully!");
                LoadEmployeeIntoGridView();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding Employee: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "UPDATE [dbo].[Employee] SET EmployeeCode = @code,EmployeeName = @name, Position = @pos, AuthorityLevel = @AL,Username = @us , Password = @ps WHERE EmployeeID = @id";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@id", int.Parse(txtEmployeeID.Text));
                    cmd.Parameters.AddWithValue("@name", txtName.Text);
                    cmd.Parameters.AddWithValue("@code", txtCode.Text);


                    cmd.Parameters.AddWithValue("@pos", txtPosition.Text);
                    cmd.Parameters.AddWithValue("@AL", txtLevel.Text);
                    cmd.Parameters.AddWithValue("@us", txtUserName.Text);
                    cmd.Parameters.AddWithValue("@ps", txtPassword.Text);

                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    connection.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Employee updated successfully!");
                        LoadEmployeeIntoGridView();
                    }
                    else
                    {
                        MessageBox.Show("No Employee found with the given ID.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating Employee: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "DELETE FROM [dbo].[Employee] WHERE EmployeeID = @id";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@id", int.Parse(txtEmployeeID.Text));

                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    connection.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Employee deleted successfully!");
                        LoadEmployeeIntoGridView();
                        txtEmployeeID.Clear();
                        txtCode.Clear();
                        txtName.Clear();
                        txtLevel.Clear();
                        txtPosition.Clear();
                        txtUserName.Clear();
                        txtPassword.Clear();

                    }
                    else
                    {
                        MessageBox.Show("No Employee found with the given ID.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting Employee: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminForm adminForm = new AdminForm();
            adminForm.ShowDialog();
            this.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
